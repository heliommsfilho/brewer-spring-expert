package com.algaworks.brewer.service.event.cerveja;

import org.springframework.util.StringUtils;

import com.algaworks.brewer.model.Cerveja;

// Não será mais utilizado após o S3
public class CervejaSalvaEvent {

//	private Cerveja cerveja;
//
//	public CervejaSalvaEvent(Cerveja cerveja) {
//		this.cerveja = cerveja;
//	}
//
//	public Cerveja getCerveja() {
//		return cerveja;
//	}
//	
//	public boolean temFoto() {
//		return !StringUtils.isEmpty(cerveja.getFoto());
//	}
//	
//	public boolean isFotoNova() {
//		return cerveja.isNovaFoto();
//	}
}
