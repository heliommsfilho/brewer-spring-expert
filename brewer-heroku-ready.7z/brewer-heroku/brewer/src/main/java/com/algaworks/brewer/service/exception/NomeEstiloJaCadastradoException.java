package com.algaworks.brewer.service.exception;

public class NomeEstiloJaCadastradoException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4954418062125355375L;
	
	public NomeEstiloJaCadastradoException(String message) {
		super(message);
	}

}
