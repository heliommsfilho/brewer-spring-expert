package com.algaworks.brewer.service.exception;

public class UsuarioEmailJaCadastradoException extends RuntimeException {

	private static final long serialVersionUID = 5498666435598712373L;

	public UsuarioEmailJaCadastradoException(String message) {
		super(message);
	}
}
