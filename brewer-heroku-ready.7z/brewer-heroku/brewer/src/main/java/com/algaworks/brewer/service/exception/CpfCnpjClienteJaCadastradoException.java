package com.algaworks.brewer.service.exception;

public class CpfCnpjClienteJaCadastradoException extends RuntimeException {

	private static final long serialVersionUID = -4315295282130595280L;

	public CpfCnpjClienteJaCadastradoException(String message) {
		super(message);
	}
}
