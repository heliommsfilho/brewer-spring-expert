package com.algaworks.brewer.service.exception;

public class NomeCidadeJaCadastradaException extends RuntimeException {

	private static final long serialVersionUID = 6789530128568989901L;

	public NomeCidadeJaCadastradaException(String message) {
		super(message);
	}
}
